const express = require('express')
const mongoose = require('mongoose')
const router = express.Router()
const Employee = mongoose.model('Employee')
router.get('/',(req,res)=>{
     res.render("NewEmp")
})
router.post('/save',(req,res)=>{
     const emp = new Employee()
     emp.empid = req.body.empid
     emp.ename = req.body.ename
     emp.desig = req.body.desig
     emp.basic = req.body.basic
     emp.save((err)=>{
          if(!err)
               console.log("Database Connected Succesfully")
     })
})
module.exports=router