//const mongoose = require('mongoose')

const employeeSchema = new mongoose.Schema({
     empid:Number,
     ename:String,
     desig:String,
     basic:Number
})
mongoose.model('Employee',employeeSchema)

